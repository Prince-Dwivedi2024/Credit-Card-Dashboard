-- =============================================
-- 2. DATA CLEANING AND STANDARDIZATION
-- =============================================

-- Remove duplicates
DELETE FROM customer
WHERE Client_Num IN (
    SELECT Client_Num FROM (
        SELECT Client_Num, ROW_NUMBER() OVER (PARTITION BY Client_Num ORDER BY Client_Num) AS rn
        FROM customer
    ) t WHERE t.rn > 1
);

-- Replace NULLs or blanks with defaults
UPDATE customer
SET Education_Level = COALESCE(Education_Level, 'Unknown'),
    Marital_Status = COALESCE(Marital_Status, 'Unknown'),
    Gender = COALESCE(Gender, 'Not Specified');

-- Handle missing financial data
UPDATE credit_card
SET Credit_Limit = COALESCE(Credit_Limit, 0),
    Total_Revolving_Bal = COALESCE(Total_Revolving_Bal, 0),
    Avg_Utilization_Ratio = COALESCE(Avg_Utilization_Ratio, 0);

-- Standardize categorical values
UPDATE credit_card
SET `Use Chip` = CASE
    WHEN `Use Chip` IN ('Yes', 'Y', 'y') THEN 'Yes'
    WHEN `Use Chip` IN ('No', 'N', 'n') THEN 'No'
    ELSE 'Unknown'
END;
