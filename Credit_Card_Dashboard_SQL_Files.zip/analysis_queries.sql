-- =============================================
-- 3. ANALYTICAL QUERIES FOR POWER BI DASHBOARD
-- =============================================

-- Spending trend over time
SELECT
    current_year,
    Qtr,
    SUM(Total_Trans_Amt) AS Total_Spending
FROM cc_add
GROUP BY current_year, Qtr
ORDER BY current_year, Qtr;

-- Revenue by Expenditure Type
SELECT
    `Exp Type`,
    SUM(Total_Trans_Amt) AS Total_Revenue
FROM credit_card
GROUP BY `Exp Type`
ORDER BY Total_Revenue DESC;

-- Average Utilization by Card Category
SELECT
    Card_Category,
    ROUND(AVG(Avg_Utilization_Ratio), 2) AS Avg_Utilization
FROM credit_card
GROUP BY Card_Category
ORDER BY Avg_Utilization DESC;

-- Customer-level insights: income vs satisfaction
SELECT
    Gender,
    ROUND(AVG(Income), 2) AS Avg_Income,
    ROUND(AVG(Cust_Satisfaction_Score), 2) AS Avg_Satisfaction
FROM cust_add
GROUP BY Gender;

-- Top 10 states by total transaction volume
SELECT
    c.state_cd,
    SUM(cc.Total_Trans_Amt) AS Total_Amount
FROM customer c
JOIN credit_card cc ON c.Client_Num = cc.Client_Num
GROUP BY c.state_cd
ORDER BY Total_Amount DESC
LIMIT 10;
