-- =============================================
-- 1. CREATE TABLES FOR CREDIT CARD DASHBOARD
-- =============================================

CREATE TABLE customer (
    Client_Num              VARCHAR(20) PRIMARY KEY,
    Customer_Age            INT,
    Gender                  VARCHAR(10),
    Dependent_Count         INT,
    Education_Level         VARCHAR(50),
    Marital_Status          VARCHAR(20),
    state_cd                VARCHAR(10),
    Zipcode                 VARCHAR(10),
    Car_Owner               VARCHAR(5),
    House_Owner             VARCHAR(5),
    Personal_loan           VARCHAR(5),
    contact                 VARCHAR(20),
    Customer_Job            VARCHAR(100),
    Income                  DECIMAL(12,2),
    Cust_Satisfaction_Score INT
);

CREATE TABLE credit_card (
    Client_Num              VARCHAR(20),
    Card_Category           VARCHAR(50),
    Annual_Fees             DECIMAL(10,2),
    Activation_30_Days      INT,
    Customer_Acq_Cost       DECIMAL(10,2),
    Week_Start_Date         DATE,
    Week_Num                INT,
    Qtr                     VARCHAR(10),
    current_year            INT,
    Credit_Limit            DECIMAL(12,2),
    Total_Revolving_Bal     DECIMAL(12,2),
    Total_Trans_Amt         DECIMAL(12,2),
    Total_Trans_Vol         INT,
    Avg_Utilization_Ratio   DECIMAL(5,2),
    `Use Chip`              VARCHAR(10),
    `Exp Type`              VARCHAR(50),
    Interest_Earned         DECIMAL(10,2),
    Delinquent_Acc          INT,
    FOREIGN KEY (Client_Num) REFERENCES customer(Client_Num)
);

CREATE TABLE cc_add (
    Client_Num              VARCHAR(20),
    Card_Category           VARCHAR(50),
    Annual_Fees             DECIMAL(10,2),
    Activation_30_Days      INT,
    Customer_Acq_Cost       DECIMAL(10,2),
    Week_Start_Date         DATE,
    Week_Num                INT,
    Qtr                     VARCHAR(10),
    current_year            INT,
    Credit_Limit            DECIMAL(12,2),
    Total_Revolving_Bal     DECIMAL(12,2),
    Total_Trans_Ct          INT,
    Total_Trans_Amt         DECIMAL(12,2),
    Avg_Utilization_Ratio   DECIMAL(5,2),
    `Use Chip`              VARCHAR(10),
    `Exp Type`              VARCHAR(50),
    Interest_Earned         DECIMAL(10,2),
    Delinquent_Acc          INT,
    FOREIGN KEY (Client_Num) REFERENCES customer(Client_Num)
);

CREATE TABLE cust_add (
    Client_Num              VARCHAR(20),
    Customer_Age            INT,
    Gender                  VARCHAR(10),
    Dependent_Count         INT,
    Education_Level         VARCHAR(50),
    Marital_Status          VARCHAR(20),
    state_cd                VARCHAR(10),
    Zipcode                 VARCHAR(10),
    Car_Owner               VARCHAR(5),
    House_Owner             VARCHAR(5),
    Personal_loan           VARCHAR(5),
    contact                 VARCHAR(20),
    Customer_Job            VARCHAR(100),
    Income                  DECIMAL(12,2),
    Cust_Satisfaction_Score INT,
    FOREIGN KEY (Client_Num) REFERENCES customer(Client_Num)
);
